import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-public-pages',
  templateUrl: './public-pages.component.html',
  styleUrls: ['./public-pages.component.css']
})
export class PublicPagesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
